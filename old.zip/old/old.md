# Old

Just using this folder to store old code unless I need to refer back to it.
The code here is not used in the modern rewrite of the project.